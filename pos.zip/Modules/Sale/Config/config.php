<?php

return [
    'name' => 'Sale'
];
